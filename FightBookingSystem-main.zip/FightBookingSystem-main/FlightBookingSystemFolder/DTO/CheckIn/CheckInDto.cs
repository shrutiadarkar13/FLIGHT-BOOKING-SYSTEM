namespace FlightBookingSystemFolder.DTO.CheckIn
{
    public class CheckInDto
    {
        public int Check_Id{get;set;}
        public int Seat_Allocation{get;set;}
    }

}