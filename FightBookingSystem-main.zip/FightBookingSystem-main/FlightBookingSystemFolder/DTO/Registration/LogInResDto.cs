using System.ComponentModel.DataAnnotations;

namespace FlightBookingSystemFolder.DTO.Registration
{
    public class LogInResDto
    {   
        public string Email{get;set;}
        public string Token{get;set;}
        
        
    }

}