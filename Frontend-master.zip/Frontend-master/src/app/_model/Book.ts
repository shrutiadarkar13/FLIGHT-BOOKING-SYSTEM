export interface Book{
      passenger_Name:string ;
    city:string;
     country:string;
     passport_No :string;
   phoneNumber :string;
     gender:string;
    age:number;
   email:string;
   
}