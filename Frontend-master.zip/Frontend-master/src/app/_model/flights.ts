

export interface Flight{
    name: string;
    to:string;
    from:string;
    fare:number;
    flight_Id:number;
    //datetime:VariableBinding;
}